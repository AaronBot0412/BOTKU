const donasi = (prefix) => {
	return `𝗡𝗢𝗘𝗘𝗥𝗕𝗢𝗧
          
❉──────────❉

*🔰_BotAaron_🔰*

❉──────────❉

*ini dia kak menu donasi, makasih ya udah mau donasi.*
📆 *TANGGAL: %day_of_month%-%month%-%year%*
📌STATUS BOT AKTIF: *wa.me/+1 (831) 353-5216*

┏━━━━°❀ ❬ 𝘼𝘽𝙊𝙐𝙏 ❭ ❀°━━━━┓
┃╔═══════════════════╗
┏❉ *${prefix}info*
┃❉ *${prefix}help* 
┗❉ *${prefix}creator* 
┃╚═══════════════════╝
┣━━━━°❀ ❬ 𝗗𝗢𝗡𝗔𝗦𝗜 ❭ ❀°━━━⊱
┃╔═══════════════════╗
┃╠➥ *GOPAY:* 
┃╠➥ *PULSA:*+62 822-4658-6611
┃╠➥ *KUOTA:*+62 822-4658-6611 
┃╚═══════════════════╝
┣━━━━━━━━━━━━━━━━━━━━━⊱
┃
┃          🔰_BotAaron_🔰
┃      ▌│█║▌║▌║║▌║▌║█│▌
┃      ▌│█║▌║▌║║▌║▌║█│▌
┃          🔰_BotAaron_🔰
┃
┣━━━━━━━━━━━━━━━━━━━━━┓
┃  _*𝐏𝐎𝐖𝐄𝐑𝐃 𝐁𝐘 @Aaron*_
┗━━━━━━━━━━━━━━━━━━━━━┛
}

exports.donasi = donasi
