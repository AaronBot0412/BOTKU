
const help = (prefix) => { 
	return `    
	
❉──────────❉

*🔰_BotAaron_🔰*

❉──────────❉

📆 *TANGGAL: %day_of_month%-%month%-%year%*
📌STATUS BOT AKTIF: *wa.me/+1 (831) 353-5216*
       	
┏━━━━°❀ ❬ 𝘼𝘽𝙊𝙐𝙏 ❭ ❀°━━━━┓
┃╔═══════════════════╗
┏❉ *${prefix}owner*
┣❉ *${prefix}donasi*
┗❉ *${prefix}info*
┃╚═══════════════════╝
┣━━━━°❀ ❬ 𝗠𝗔𝗞𝗘𝗥 ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}sticker*
┃╠➥ *${prefix}sticker nobg*
┃╠➥ *${prefix}tsticker*
┃╠➥ *${prefix}nulis*
┃╠➥ *${prefix}logowolf*
┃╚═══════════════════╝
┣━━━━°❀ ❬ 𝙈𝙀𝘿𝙄𝘼 ❭ ❀°━━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}tts*
┃╠➥ *${prefix}tiktok*
┃╠➥ *${prefix}meme*
┃╠➥ *${prefix}memeindo*
┃╠➥ *${prefix}nsfwloli* 
┃╠➥ *${prefix}ocr*
┃╠➥ *${prefix}neko*
┃╠➥ *${prefix}randomanime*
┃╠➥ *${prefix}loli*
┃╠➥ *${prefix}waifu*
┃╚═══════════════════╝
┣━━━°❀ ❬ 𝘿𝙊𝙒𝙉𝙇𝙊𝘼𝘿 ❭ ❀°━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}ytmp3*
┃╠➥ *${prefix}ytmp4*
┃╚═══════════════════╝
┣━━━━°❀ ❬ 𝙂𝙍𝙊𝙐𝙋 ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}add* [62xxx]
┃╠➥ *${prefix}kick* [tag]
┃╠➥ *${prefix}setpp*
┃╠➥ *${prefix}tagme*
┃╠➥ *${prefix}demote* [tag]
┃╠➥ *${prefix}promote* [tag]
┃╠➥ *${prefix}grup* [buka/tutup]
┃╠➥ *${prefix}welcome* [1/0]
┃╠➥ *${prefix}nsfw* [1/0]
┃╠➥ *${prefix}simih* [1/0]
┃╚═══════════════════╝
┣━━━━°❀ ❬ 𝙊𝙒𝙉𝙀𝙍 ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}bc* 
┃╠➥ *${prefix}clearall*
┃╠➥ *${prefix}setprefix*
┃╠➥ *${prefix}leave*
┃╠➥ *${prefix}clone* [tag]
┃╚═══════════════════╝
┣━━━━━°❀ ❬ 𝙎𝙋𝘼𝙈 ❭ ❀°━━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}spamsms*
┃╠➥ *${prefix}spamcall*
┃╠➥ *${prefix}spamgmail*
┃╚═══════════════════╝
┣━━━━°❀ ❬ 𝙊𝙏𝙃𝙀𝙍 ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}ytsearch*
┃╠➥ *${prefix}listadmin*
┃╠➥ *${prefix}blocklist*
┃╠➥ *${prefix}wait*
┃╠➥ *${prefix}nama*
┃╠➥ *${prefix}map*
┃╠➥ *${prefix}qrcode*
┃╠➥ *${prefix}tiktokstalk*
┃╠➥ *${prefix}shortlink*
┃╠➥ *${prefix}url2img*
┃╠➥ *${prefix}alay*
┃╠➥ *${prefix}quotes*
┃╠➥ *${prefix}bucin*
┃╠➥ *${prefix}wiki*
┃╠➥ *${prefix}wikien*
┃╚═══════════════════╝
┣━━━━°❀ ❬ 𝙎𝙊𝙐𝙉𝘿 ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}tapi*
┃╚═══════════════════╝
┣━━━━━━━━━━━━━━━━━━━━━⊱
┃
┃          🔰_BotAaron_🔰
┃      ▌│█║▌║▌║║▌║▌║█│▌
┃      ▌│█║▌║▌║║▌║▌║█│▌
┃          🔰_BotAaron_🔰
┃
┣━━━━━━━━━━━━━━━━━━━━━┓
┃  _*𝐏𝐎𝐖𝐄𝐑𝐃 𝐁𝐘 @Aaron*_
┗━━━━━━━━━━━━━━━━━━━━━┛
}

exports.help = help

 